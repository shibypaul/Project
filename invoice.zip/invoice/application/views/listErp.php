<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <title>ERP</title>
      <style>
        .result{
         color:red;
        }
        td
        {
          text-align:center;
        }
      </style>
   </head>
   <body> 
      <section class="mt-3">
         <div class="container-fluid">
         <h4 class="text-center" style="color:green"> Abc Super Market </h4>
         <h6 class="text-center"> Ernakulam</h6>
         <div class="row">
            <div class="col-md-5  mt-4 ">
               <table class="table" style="background-color:#f5f5f5;">
                  <thead>
                     <tr>
                        <th>No.</th>
                        <th>Products</th>
                        <th style="width: 31%">Qty</th>
                        <th>Price</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td scope="row">1</td>
                        <td style="width:60%">
                           <select title="sel" name="prod" id="prod"  class="form-control">
                              <?php 
                              	foreach ($data as $row){ 
							  ?>
                              <option id="<?php echo $row['id']; ?>" value="<?php echo $row['product_name']; ?>" class="prod custom-select">
                                 <?php echo $row['product_name']; ?>
                              </option>
                              <?php  }?>   
                           </select>
                        </td>
                        <td style="width:1%">
                          <input type="number" id="qty" min="0" value="0" class="form-control">
                        </td>
                        <td>
                           <p id="price"></p>
                        </td>
                       
						 <td><button id="add" class="btn btn-primary">Add</button></td>
                     </tr>
                  </tbody>
               </table>
               <div role="alert" id="errorMsg" class="mt-5" >
                 <!-- Error msg  -->
              </div>
            </div>
            <div class="col-md-7  mt-4" style="background-color:#f5f5f5;">
               <div class="p-4">
                  <div class="text-center">
                     <h4>Receipt</h4>
                  </div>
                  <span class="mt-4">   </span>
                  <div class="row">
                     <div class="col-xs-6 col-sm-6 col-md-6 ">                        
                     </div>
                     <div class="col-xs-6 col-sm-6 col-md-6 text-right">                      
                     </div>
                  </div>
                  <div class="row">
                     </span>
                     <table id="receipt_bill" class="table">
                        <thead>
                           <tr>
                              <th> No.</th>
                              <th>Product Name</th>
                              <th>Quantity</th>
                              <th class="text-center">Price</th>
							  <th class="text-center">Total</th>
                           </tr>
                        </thead>
                        <tbody id="new" >
                          
                        </tbody>
                        <tr>
                           <td> </td>
                           <td> </td>
                           <td> </td>
                           <td class="text-right text-dark" >
                                <h5><strong>Sub Total:   </strong></h5>
							    <p><strong>Tax (%) :  </strong>
							   	<select title="ta" name="tax" id="tax"  >
								  <option id="0" value="0" class="tax custom-select"> 0%</option>
								  <option id="1" value="1" class="tax custom-select"> 1%</option>
								  <option id="5" value="5" class="tax custom-select"> 5%</option>
								  <option id="10" value="10" class="tax custom-select"> 10%</option>
                         		 </select>
							   </p>
							   <p><strong>Sub Total With Tax :  </strong>
							   <p><strong>Discount (%) :  </strong>
							   	<select title="disc" name="disc" id="disc"  >
								  <option id="0" value="0" class="disc custom-select"> 0%</option>
								  <option id="5" value="5" class="disc custom-select"> 5%</option>
								  <option id="10" value="10" class="disc custom-select"> 10%</option>
								  <option id="20" value="20" class="disc custom-select"> 20%</option>
								  <option id="50" value="50" class="disc custom-select">50%</option>
                         		 </select>
							   </p>
							   <!-- <td style="width:1%"> -->
						 
						<!-- </td>-->
                           </td>
							
                           <td class="text-center text-dark" >
                              <h5> <strong><span id="subTotal"></strong></h5>
                              <h5> <strong><span id="taxAmount"></strong></h5>
							  <h5> <strong><span id="totalWithtaxAmount" class="text-danger"></strong></h5>
                           </td>
                        </tr>
                        <tr>
                           <td> </td>
                           <td> </td>
                           <td> </td>
                           <td class="text-right text-dark">
                              <h5><strong>Price:  </strong></h5>
                           </td>
                           <td class="text-center text-danger">
                              <h5 id="Payment"><strong> </strong></h5>                               
                           </td>
                        </tr>
                     </table>
							   <a href="<?php echo site_url('Erp/printInvoice'); ?>/" class="btn btn-primary" >Generate Invoice</a>
					<!--<button id="add" class="btn btn-primary"></button>		   -->
                  </div>
               </div>
            </div>
         </div>
      </section>
   </body>
</html>
	
<script type="text/javascript">
    $(document).ready(function(){ 
     $('#prod').change(function() { 
      var id = $(this).find(':selected')[0].id; 
       $.ajax({
          method:'POST',
          url:"<?php echo site_url('Erp/priceGet'); ?>",
          data:{id:id},
          dataType:'json',
          success:function(data)
            { 
               $('#price').text(data.product_price);
            }
       }); 
     });
	});
	
	 //add products
     var count = 1;
     $('#add').on('click',function(){
    
        var name = $('#prod').val();
        var qty = $('#qty').val();
        var price = $('#price').text();
 
        if(qty == 0)
        {
           var erroMsg =  '<span class="alert alert-danger ml-5">Minimum Qty should be 1 or More than 1</span>';
           $('#errorMsg').html(erroMsg).fadeOut(3000);
        }
        else
        {
           billFunction(); 
        }
         
        function billFunction()
          {
          var total = 0;
       
          $("#receipt_bill").each(function () {
          var total =  price*qty;
          var subTotal = 0;
			subTotal = subTotal + total;
          
          var table =   '<tr><td>'+ count +'</td><td>'+ name + '</td><td>' + qty + '</td><td>$' + price + '</td><td><strong>$<input type="hidden" id="total" value="'+total+'">' +total+ '</strong></td></tr>';
          $('#new').append(table)
 
           // Code for Sub Total of products 
            var total = 0;
            $('tbody tr td:last-child').each(function() {
                var value = parseInt($('#total', this).val());
                if (!isNaN(value)) {
                    total += value;
                }
            });
             $('#subTotal').text(total);			  
               
            // Code for calculate the tax against subtotal
			  
			  $('#tax').on('click',function(){
				  var ta = $('#tax').val(); //alert(ta);
				  if( ta== 0 ){
					 var Tax = (total * 0) / 100;
				  } else if( ta== 1 ){
					  var Tax = (total * 1) / 100;
				  } else if( ta== 5 ){
					var Tax = (total * 5) / 100;
				  }else if( ta== 10 ){
					  var Tax = (total * 10) / 100;
				  }
				   $('#taxAmount').text(Tax.toFixed(2));
 
             // Code for Total Payment Amount
 
             var Subtotal = $('#subTotal').text();
             var taxAmount = $('#taxAmount').text(); 
             var totalPayment = parseFloat(Subtotal) + parseFloat(taxAmount);
		     var totalWithtaxAmount = $('#totalPayment').text(); //alert(totalPayment);
            // $('#totalPayment').text(totalPayment.toFixed(2)); 
			 $('#totalWithtaxAmount').text(totalPayment.toFixed(2));
		     
			 $('#disc').on('click',function(){
				 var dis = parseInt($('#disc').val()); 
				 var dis1 = parseFloat(totalPayment); 
				 var disAmount = 0;
				  if( dis == 0 ){
					 var dis = (parseFloat(totalPayment) * 0) / 100; 
					 var disAmount = parseFloat(totalPayment) - parseFloat(dis);
				  } else if( dis == 5 ){
					 var dis = (parseFloat(totalPayment) * 5) / 100; 
					 var disAmount = parseFloat(totalPayment) - parseFloat(dis);
				  } else if( dis == 10 ){ 
					  var dis = (parseFloat(totalPayment) * 10) / 100; 
					  var disAmount = parseFloat(totalPayment) - parseFloat(dis);	
				  } else if( dis == 20 ){
					var dis = (parseFloat(totalPayment) * 20) / 100;
					  var disAmount = parseFloat(totalPayment) - parseFloat(dis);	
				  }else if( dis == 50 ){
					  var dis = (parseFloat(totalPayment) * 50) / 100;
					  var disAmount = parseFloat(totalPayment) - parseFloat(dis);	
				  } 
				  $('#Payment').text(disAmount.toFixed(2)); 
 
             
			 });
				  
			 });
			  
			 
			  
			  
			 
             
        
         });
         count++;
        } 
       });	
	
</script>
	
    
     