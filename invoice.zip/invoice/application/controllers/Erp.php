<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Erp extends CI_Controller {
	
	public function __construct()
    {
          parent::__construct();
		$this->load->database();
          $this->load->model('ErpModel');
	}
	
	public function index()
	{	$result['data'] = $this->ErpModel->loadItems();
		$this->load->view('listErp',$result);
	}
	
	public function priceGet(){ 
		$id = $this->input->post('id'); 
	 	$data = $this->ErpModel->itemPrice($id);
	 	echo json_encode($data);
	}
	
	public function printInvoice() {/*
		$one = "<p>hi</p>";
		$two = "<p>hi-hhh</p>";
		$generated= "<span class='rights'>Generated on ".date("F j Y,  g:i a")."</div>";
		$mpdf->WriteHTML($one.$two);
		$mpdf->Output(); */
		

 $mpdf = new mpdf('',    // mode - default ''
                           'A4',    // format - A4, for example, default ''
                           10,     // font size - default 0
                           'Courier New',    // default font family
                           10,    // margin_left
                           10,    // margin right
                           10,     // margin top
                           10,    // margin bottom
                           9,     // margin header
                           9,     // margin footer
                           'P');  // L - landscape, P - portrait
$mpdf->WriteHTML('<h1>Hello </h1>');
$mpdf->Output();
	}
}
