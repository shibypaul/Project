<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ErpModel extends CI_Model {
	
	public function __construct(){
        parent::__construct();	 
	}
	
	public function loadItems(){
		$result = $this->db->get('orders');
		return $result->result_array();
	}
	
	public function itemPrice($price_id){
		$query = $this->db->select('product_price')
						  ->from('orders')
			              ->where('id',$price_id)
						  ->get();
		return $query->row_array();
	}
	
}
